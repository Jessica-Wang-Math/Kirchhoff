import java.util.Arrays;
import java.util.Objects;

/**
 * Edge object, used in a Kirchhoff object
 */
public class Edge {

    int[] head; //head coordinate
    int[] tail; //tail coordinate
    int weight; //hash marks on edges

    public Edge(int[] head,int[] tail,int weight)
    {
        this.head=head;
        this.tail=tail;
        this.weight=weight;
    }

    public boolean equal_to(Edge other)
    {
        if(Arrays.equals(this.head,other.head) && Arrays.equals(this.tail,other.tail))
            return true;
        return false;
    }

    public boolean vector_equals(Edge other) {
        return difX() == other.difX() && difY() == other.difY();
    }

    public int difX() {
        return head[0] - tail[0];
    }

    public int difY() {
        return head[1] - tail[1];
    }


    public Edge clone() {
        return new Edge(Arrays.copyOf(head, head.length), Arrays.copyOf(tail, tail.length), weight);
    }

    @Override
    public boolean equals(Object obj) {
        if(!(obj instanceof Edge))
            return false;
        return vector_equals((Edge) obj);
    }

    @Override
    public int hashCode() {
        return Objects.hash(Arrays.hashCode(head), Arrays.hashCode(tail), weight);
    }
}
