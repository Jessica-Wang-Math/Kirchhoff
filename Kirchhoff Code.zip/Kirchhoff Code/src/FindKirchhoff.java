import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;
import com.sun.tools.corba.se.idl.toJavaPortable.Helper;
import org.apache.commons.math3.fraction.Fraction;

import java.io.*;
import java.util.*;
import java.lang.Math;
import java.util.stream.IntStream;

/**
 * Given a Row matrix, a Null matrix, and a multiplicity,
 * constructs all Kirchhoff graphs with given multiplicity
 * or return null if none exists
 */
public class FindKirchhoff {
    int[][] RowSpace;
    int[][] NullSpace;
    int[][] edges; //edges from RowSpace
    int n = 5; //num of vectors
    int m; //multiplicity
    ArrayList<int[]> store;
    FileWriter writer = null;
    int count=0;
    double progress=0;
    int total_cuts;
    int iterator=0;
    int gap = 5000;

    /**
     * Arg1 is multiplicity
     * Arg2 is row matrix
     * Arg3 is output
     */
    public static void main(String[] args) throws IOException {

        FindKirchhoff f = new FindKirchhoff();
//
//        final double[] sec = {0};
//        Timer timer = new Timer(false);
//        TimerTask task = new TimerTask() {
//            @Override
//            public void run() {
//                System.out.println("time = "+ sec[0]*5+" progress = " + f.progress);
//                sec[0]++;
//            }
//        };
//        timer.scheduleAtFixedRate(task, 0, 5000);
//        f.find_kirchhoff_driver(args);
//        timer.cancel();

        f.read_and_save("/Users/jessicawang/Desktop/Mar1.txt"); //enter your path

    }

    public void find_kirchhoff_driver(String[] args) throws IOException {
        if(args.length==3)
        {
            int multiplicity = Integer.parseInt(args[0]);
            int[][] r = stringToArray(args[1]);
            File outputFile = new File(args[2]);

            if (outputFile.exists()) {
                outputFile.delete();
            }
            outputFile.createNewFile();

            try(FileWriter writer = new FileWriter(outputFile, true)) {
                find_kirchhoff_with_matrix(r, multiplicity, writer, outputFile);
            }
        }
        else
        {
            int multiplicity = Integer.parseInt(args[0]);
            int[][] r = stringToArray(args[1]);
            int[][] store = stringToArray(args[2]);
            File outputFile = new File(args[3]);

            if (outputFile.exists()) {
                outputFile.delete();
            }
            outputFile.createNewFile();

            try(FileWriter writer = new FileWriter(outputFile, true)) {
                find_kirchhoff_with_cuts(r, store, multiplicity, writer,outputFile);
            }
        }
        //graph_one_line("1 {loV:[{position:[0,0],cut:[0,0,0,0]}],loE:[]}");
    }


    /**
     * @param path = path of file to be read
     * Read a .txt file with Kirchhoff graphs information
     * Draws them via Java Graphics
     * Saves them as PNGs
     * @throws FileNotFoundException
     * https://www.easepdf.com/png-to-pdf/
     */
    public void read_and_save(String path) throws FileNotFoundException {
        File file = new File(path);
        Scanner s = new Scanner(file);

        while (s.hasNextLine())
        {
            String line = s.nextLine().trim();
            if (line.isEmpty()) continue;
            String[] parts = line.split(" ");
            int index = (int) Long.parseLong(parts[0]) - 1;
            JsonReader reader = new JsonReader(new StringReader(parts[1]));
            reader.setLenient(true);

            Kirchhoff graph = new Gson().fromJson(reader, Kirchhoff.class);
            print_and_draw(graph,index);
        }
    }

    /**
     * reads string in input file to match Kirchhoff format
     * @return s in array format
     */
    public static int[][] stringToArray(String s) {
        //https://stackoverflow.com/a/29547534
        // Split on this delimiter
        String[] rows = s.replace("{", "[").replace("}", "]").split("], \\[");
        for (int i = 0; i < rows.length; i++) {
            // Remove any beginning and ending braces and any white spaces
            rows[i] = rows[i].replace("[[", "").replace("]]", "").replaceAll(" ", "");
        }

        // Get the number of columns in a row
        int numberOfColumns = rows[0].split(",").length;

        // Setup your matrix
        String[][] matrix = new String[rows.length][numberOfColumns];

        // Populate your matrix
        for (int i = 0; i < rows.length; i++) {
            matrix[i] = rows[i].split(",");
        }

        int[][] intMatrix = new int[rows.length][numberOfColumns];
        for (int i = 0; i < rows.length; i++) {
            for (int j = 0; j < numberOfColumns; j++) {
                intMatrix[i][j] = Integer.parseInt(matrix[i][j]);
            }
        }

        return intMatrix;
    }

    /**
     * Display graph given line of text
     * @param text Kirchhoff object in text format (converted by Gson)
     */
    public void graph_one_line(String text)
    {
        Gson gson = new Gson();
        String json = text;
        Kirchhoff testK = gson.fromJson(json,Kirchhoff.class);
        print_and_draw(testK, 00);

    }




    /**
     * using exhaustive search algorithm to construct all prime
     * kirchhoff graphs given matrix. return null if none is found.
     *
     * @param visited     list with visited vertices
     * @param todo        list with vertices needs to check
     * @param graph       current Kirchhoff graph (a Kirchhoff object with vertices and edges)
     * @param answers     accumulator for constructed graphs
     * @return a Kirchhoff graph, a list of Kirchhoff graphs, or null
     */
    public Kirchhoff algo(ArrayList<Vertex> visited, Queue<Vertex> todo, Kirchhoff graph, ArrayList<Kirchhoff> answers, File output) {

        //graph is Kirchhoff
        if (todo.isEmpty() && every_cut_is_correct(graph)) {
            boolean contains = false;
            for (Kirchhoff a : answers) {
                if (graph.is_the_same(a)) {
                    contains = true;
                    break;
                }
            }
            if (!contains) {
                answers.add(graph);
                //System.out.print("Iterator = "+iterator);
                count++;
                try(FileWriter writer = new FileWriter(output,true)) {
                    writer.write(count+" ");
                    writer.write(new Gson().toJson(graph, Kirchhoff.class) + "\n \n");
                } catch (IOException e) {
                    e.printStackTrace();
                }
                //return graph;
            }
            this.progress+=1/(Math.pow(total_cuts,graph.depth));
            graph.depth=graph.depth-2;
            draw_with_gap(graph);
//            graph.enumerate=iterator;
//            iterator++;
            return null;
        }

        if (!satisfies_multiplicity(m, graph) || todo.isEmpty())
        {
            progress+=1/(Math.pow(total_cuts,graph.depth));
            graph.depth--;
            draw_with_gap(graph);
//            graph.enumerate=iterator;
//            iterator++;
            return null;
        }

        if (graph.loV.size() > 1) {
            if (every_cut_is_correct(graph)) {
                //check if graph is already in list_of_graphs
                boolean contains = false;
                for (Kirchhoff a : answers) {
                    if (graph.is_the_same(a)) {
                        contains = true;
                        break;
                    }
                }
                if (!contains) {
                    answers.add(graph);
                    //System.out.print("Iterator = "+iterator);
                    count++;
                    try (FileWriter writer = new FileWriter(output, true)) {
                        writer.write(count + " ");
                        writer.write(new Gson().toJson(graph, Kirchhoff.class) + "\n \n");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                progress+=1/(Math.pow(total_cuts,graph.depth));
                graph.depth=graph.depth-2;
                draw_with_gap(graph);
//                graph.enumerate=iterator;
//                iterator++;
                return null;
            }
        }

        Vertex ver = todo.poll();

        for (int i = 0; i < store.size(); i++) {
            if (visited.size() == 0 && graph.loE.size() == 0) {
                //skip if does not satisfy diagonal
                if(array_is_zero(store.get(i)))
                    continue;
                if (!satisfies_diagonal(ver, store.get(i), graph)) {
                    progress+=1/(Math.pow(total_cuts,graph.depth+1));
                    continue;
                }
            }
            if(Arrays.equals(ver.cut,store.get(i)))
            {
                visited.add(ver);
                Queue<Vertex> new_todo = up_to_date_todo(todo, graph);
                Kirchhoff result = algo(visited, new_todo, graph, answers, output);
                if (result != null) return result;
            }
            else
            {
                int cut_property = cut_is_correct(ver, store.get(i));
                if (cut_property != -1) {
                    if (will_satisfy_multiplicity(ver, store.get(i), graph)) {
                        Kirchhoff updated_graph = add_edges_and_vertices(ver, store.get(i), graph);
                        draw_with_gap(graph);
//                    graph.enumerate=iterator;
//                    iterator++;
                        //make copy of to-do and visited
                        LinkedList<Vertex> copy_todo = new LinkedList<>(todo);
                        ArrayList<Vertex> copy_visited = new ArrayList<>(visited);
                        //visited.add(ver);
                        Vertex updated_v = update_vertex(ver,store.get(i));
                        visited.add(updated_v);
                        update_todo(ver, store.get(i), todo, visited, graph); //check if ver is visited
                        Queue<Vertex> new_todo = up_to_date_todo(todo, updated_graph);
                        //new recursive call
                        updated_graph.depth++;
                        Kirchhoff result = algo(visited, new_todo, updated_graph, answers,output);
                        if (result != null) return result;
                        //if doesn't work, convert back to to-do
                        todo = copy_todo;
                        visited = copy_visited;
                    }
                }
            }


        }

        //if no cuts work for vertex, go to the next vertex in to-do
        Queue<Vertex> new_todo = up_to_date_todo(todo, graph);
        //return algo(visited, new_todo, graph, answers,output);
        draw_with_gap(graph);
//        graph.enumerate=iterator;
//        iterator++;
        return null;
    }

    public void draw_with_gap(Kirchhoff graph)
    {
        //if(iterator>135500 || iterator==4281)
//        if(iterator==42544)
//            print_and_draw(graph,iterator);

//        if(iterator>42000 && iterator%1==0)
//            print_and_draw(graph,iterator);
        graph.enumerate=iterator;
        iterator++;
    }

    /**
     * the new edge added must be on the right side of the diagonal of the current vertex
     * @return true if correct
     */
    public boolean satisfies_diagonal(Vertex ver, int[] vCut, Kirchhoff graph) {
        Kirchhoff new_KG = add_edges_and_vertices(ver, vCut, graph);
        for (Vertex v : new_KG.loV) {
            if (v.position[0] < -1 * v.position[1]) return false;
        }
        return true;
    }

    /**
     * after assigning vCut to ver, checks if the amount of each edges
     * satisfies multiplicity constraint
     *
     * @param ver   current Vertex
     * @param vCut  the cut to assign to Vertex ver
     * @param graph current Kirchhoff object
     * @return true if after adding vCut, graph still satisfies multiplicity
     */
    public boolean will_satisfy_multiplicity(Vertex ver, int[] vCut, Kirchhoff graph) {
        int[] extra = new int[vCut.length];
        for (int i = 0; i < vCut.length; i++)
            extra[i] = vCut[i] - ver.cut[i];
        //count edge multiplicities
        Map<int[], Integer> count = new HashMap<>();
        for (Edge edge : graph.loE) {
            count.merge(new int[]{edge.difX(), edge.difY()}, edge.weight, Integer::sum);
        }
        for (int[] k : count.keySet()) {
            int[][] edges = get_edges_from_matrix(RowSpace);
            for (int i = 0; i < extra.length; i++) {
                if (Arrays.equals(k, edges[i])) {
                    count.put(k, count.get(k) + extra[i]);
                }
            }
        }
        for (int value : count.values()) {
            if (value > m) return false;
        }
        return true;

    }

    /**
     * Check that cut for every vertex lies in the row space
     *
     * @param graph Kirchhoff grpah
     * @return true if all cuts are correct
     */
    public boolean every_cut_is_correct(Kirchhoff graph) {
        boolean every_cut_is_correct = true;
        //check if every cut in graph in contained in store
        for (Vertex ver : graph.loV) {
            boolean this_cut_is_correct = false;
            for (int[] c : store) {
                if (Arrays.equals(ver.cut, c)) {
                    this_cut_is_correct = true;
                    break;
                }
            }
            if (!this_cut_is_correct) {
                every_cut_is_correct = false;
                break;
            }
        }
        return every_cut_is_correct;
    }

    /**
     * Update all vertices in to-do (according to position)
     * so that they match the vertices in KG
     *
     * @param todo a list of vertices
     * @param KG   Kirchhoff graph
     * @return updated list of todo
     */
    public Queue<Vertex> up_to_date_todo(Queue<Vertex> todo, Kirchhoff KG) {
        if (todo.size() == 0) return todo;
        //update vertices in to-do
        LinkedList<Vertex> new_todo = new LinkedList<>();
        for (Vertex todo_ver : todo)
            new_todo.add(todo_ver.clone());
        for (Vertex todo_ver : new_todo) {
            for (Vertex ver : KG.loV) {
                if (Arrays.equals(todo_ver.position, ver.position)) {
                    if (!Arrays.equals(todo_ver.cut, ver.cut)) {
                        for (int i = 0; i < ver.cut.length; i++) {
                            todo_ver.cut[i] = ver.cut[i];
                        }
                    }
                }
            }
        }
        return new_todo;
    }

    /**
     * Find the neighbors of v using its vCut
     * if it's not in visited, add vertex to to-do
     * updated to-do
     */
    public void update_todo(Vertex v, int[] vCut, Queue<Vertex> todo, ArrayList<Vertex> visited, Kirchhoff graph) {

        if (array_is_zero(vCut) && !array_is_zero(v.cut)) {
            int[] new_vCut = new int[vCut.length];
            for (int i = 0; i < new_vCut.length; i++) {
                new_vCut[i] = -v.cut[i];
            }
            update_todo(v, new_vCut, todo, visited, graph);
        } else {
            for (int i = 0; i < vCut.length; i++) {
                //create new vertex
                if (vCut[i] != 0) {
                    int[] vec = edges[i]; //getting edge from matrix
                    int[] pos;
                    //add vertex:
                    if (vCut[i] > 0) pos = new int[]{v.position[0] + vec[0], v.position[1] + vec[1]};
                    else pos = new int[]{v.position[0] - vec[0], v.position[1] - vec[1]};
                    int[] current_vcut = new int[n];
                    current_vcut[i] = -1 * vCut[i];
                    Vertex newV = new Vertex(pos, current_vcut);
                    if(todo.size()==0)
                        todo.add(newV);
                    else
                    {
                        for (Vertex v_todo : todo) {
                            if (v_todo.same_position(newV)) {
//                            if(v_todo.cut[i]!=newV.cut[i])
//                            {
//                                want_to_add=true;
//
//                            }
                                v_todo.cut[i] = newV.cut[i];
                            }
                        }

                        //if not in visited or to-do!!!
                    if (visited.stream().noneMatch(newV::same_position) && todo.stream().noneMatch(newV::same_position))
                        todo.add(newV);

                    boolean want_to_add=false;

                    for(Vertex v_vis: visited)
                    {
                        if(newV.same_position(v_vis) && !Arrays.equals(newV.cut,v_vis.cut))
                        {
                            want_to_add=true;
                            break;
                        }

                    }
                    if(want_to_add)
                        todo.add(newV);
//
//                    for(Vertex ver: graph.loV)
//                    {
//                        if(newV.same_position(ver) && newV.cut[i]!=ver.cut[i]) //&& !Arrays.equals(newV.cut,ver.cut) && !array_is_zero(ver.cut))
//                            todo.add(newV);
//                    }



//                    if(not_in_list(newV,visited) && not_in_queue(newV, todo))
//                        todo.add(newV);
                }
            }
        }
    }
    }


    //check if there is identical vertex with position and cut in vList
    //visited
    public boolean not_in_list(Vertex v, ArrayList<Vertex> vList)
    {
        for(Vertex v_in_list:vList)
        {
            if(v.equals_to(v_in_list) && v.same_position(v_in_list) && v.same_cut(v_in_list))
                return false;
        }

        return true;
    }

    //to-do
    public boolean not_in_queue(Vertex v,Queue<Vertex> todo )
    {
        for(Vertex v_in_list:todo)
        {
            if(v.same_position(v_in_list) && v.same_cut(v_in_list))
                return false;
        }

        return true;
    }



    /**
     * Add cut to ver, check if new cut is correct
     *
     * @param ver vertex
     * @param cut cut
     * @return 1 if cut is correct
     * 2 if adding 2 cuts together lie in store
     * -1 if cut is not correct
     */
    public int cut_is_correct(Vertex ver, int[] cut) {
        if (array_is_zero(cut)) return 1;
        else if (Arrays.equals(ver.cut, cut)) return -1;
        else if (!array_is_zero(ver.cut) && ver.cut_is_contained_in_store(ver.subtract_cuts(cut, ver.cut), store))
            return 2;
        return 1;
    }


    /**
     * @return true if the number of each vector is less than m
     */
    public boolean satisfies_multiplicity(int m, Kirchhoff KG) {
        Map<Tuple<Integer, Integer>, Integer> count = new HashMap<>();

        for (Edge edge : KG.loE) {
            count.merge(new Tuple<>(edge.difX(), edge.difY()), edge.weight, Integer::sum);
        }

        for (int value : count.values()) {
            if (value > m) return false;
        }
        return true;
    }


    public boolean array_is_zero(int[] a) {
        for (int i : a) {
            if (i != 0) return false;
        }
        return true;
    }

    public Vertex update_vertex (Vertex in, int[] vCut)
    {
        Vertex v = new Vertex(in.position, vCut);
        return v;

    }
    /**
     * adds a set of edges and vertices at Vertex in accord to vertex cut
     * returns a new Kirchhoff object with added vertices and cuts
     *
     * @param in   current Vertex
     * @param vCut the cut to assign to Vertex
     * @param KG   current Kirchhoff object
     * @return an updated Kirchhoff object
     */
    public Kirchhoff add_edges_and_vertices(Vertex in, int[] vCut, Kirchhoff KG) {
        //makes copies
        Vertex v = new Vertex(in.position, in.cut);
        Kirchhoff newKG = KG.make_copy(KG);
        newKG.depth=KG.depth;
        //extra = the extra cut that needs to be added
        int[] extra = new int[vCut.length];
        for (int i = 0; i < vCut.length; i++)
            extra[i] = vCut[i] - in.cut[i];

        //assign vCut to Vertex 'in'
        for (Vertex ver_KG : newKG.loV) {
            if (ver_KG.same_position(in)) {
                for (int i = 0; i < vCut.length; i++)
                    ver_KG.cut[i] = vCut[i];
            }

        }
        for (int i = 0; i < extra.length; i++) {
            if (extra[i] != 0) {
                int[] vec = edges[i]; //getting edge from matrix
                int[] pos;
                //add vertex:
                if (extra[i] > 0) pos = new int[]{v.position[0] + vec[0], v.position[1] + vec[1]};
                else pos = new int[]{v.position[0] - vec[0], v.position[1] - vec[1]};
                int[] current_vcut = new int[n];
                current_vcut[i] = -1 * extra[i];
                Vertex newV = new Vertex(pos, current_vcut);

                //check is vertex is already in graph
                boolean vertex_is_unique = true;
                for (Vertex ver : newKG.loV) {
                    //if same vertex
                    if (ver.equals(newV)) {
                        vertex_is_unique = false;
                        break;
                    }
                    //if same position as some vertex
                    else if (ver.same_position(newV)) {
                        ver.cut[i] += -1 * extra[i];
                        vertex_is_unique = false;
                        break;
                    }
                }
                if (vertex_is_unique) newKG.loV.add(newV);

                Edge newE;
                //if (in.cut[i] == extra[i]) continue;
                if (extra[i] > 0) newE = new Edge(v.position, pos, extra[i]);
                else newE = new Edge(pos, v.position, -1 * extra[i]);
                boolean is_unique = true;
                for (Edge e : newKG.loE) {
                    if (newE.equal_to(e)) //if edge already exists, then add one to weight
                    {
                        e.weight=e.weight+Math.abs(extra[i]);
                        is_unique = false;
                        break;
                    }
                }
                if (is_unique) newKG.loE.add(newE);
            }
        }
        return newKG;

    }

    /**
     * given a matrix, return it's columns
     */
    public int[][] get_edges_from_matrix(int[][] r) {
        //transpose
        int i, j;
        int N1 = r[0].length;
        int N2 = r.length;

        int t[][] = new int[r[0].length][r.length]; //transposed
        for (i = 0; i < N1; i++) {
            for (j = 0; j < N2; j++)
                t[i][j] = r[j][i];
        }
        return t;
    }

    /**
     * print and draw a Kirchhoff graph
     * saves them as PNG into folder directory
     * @param final_graph Kirchhoff object
     * @param count       goes into the name of Kirchhoff in Java Graphics to enumerate
     */
    public void print_and_draw(Kirchhoff final_graph, int count) {
        GraphDraw GD = new GraphDraw();
        GD.draw_kirchhoff(final_graph, count);
        System.out.println("Vertices:");
        for (Vertex ver : final_graph.loV) {
            System.out.println("(" + ver.position[0] + ", " + ver.position[1] + ")  [" + ver.cut[0] + " " + ver.cut[1] + " " + ver.cut[2] + " " + ver.cut[3] + "]");
        }
        System.out.println("Edges:");
        for (Edge e : final_graph.loE) {
            System.out.println("(" + e.head[0] + ", " + e.head[1] + ") -> (" + e.tail[0] + ", " + e.tail[1] + ") : " + e.weight);
        }
    }

    /**
     * find all permutations of set with length k with repeats
     *
     * @param set a list of numbers
     * @param k   length k of permutations
     *            eg. set={1,2,3}, k=2 -> {{1,1},{1,2},{1,3},{2,1}...}
     */
    public ArrayList<ArrayList<Integer>> find_permutations(int[] set, int k) {
        int n = set.length;
        return find_permutations_helper(set, new ArrayList<>(), n, k, new ArrayList<ArrayList<Integer>>());
    }

    /**
     * recursive helper for find_permutations
     */
    public ArrayList<ArrayList<Integer>> find_permutations_helper(int[] set, ArrayList<Integer> prefix, int n, int k, ArrayList<ArrayList<Integer>> accum) {
        // Base case: k is 0,
        // print prefix
        if (k == 0) {
            //System.out.println(prefix+",");
            accum.add(prefix);
            return accum;
        }
        // One by one add all characters
        // from set and recursively
        // call for k equals to k-1

        for (int i = 0; i < n; ++i) {
            ArrayList<Integer> t = new ArrayList<>();
            // Next character of input added
            for (int p : prefix)
                t.add(p);
            t.add(set[i]);
            // k is decreased, because
            // we have added a new character
            find_permutations_helper(set, t, n, k - 1, accum);
        }
        return accum;
    }


    public ArrayList<int[]> find_vertex_cuts(int[][] r, int m) {
        ArrayList<int[]> all_cuts = new ArrayList<>();
        double[][] matrix = new double[r[0].length][r.length+1];


        int[]set = new int[2*m+1];
        int t =-1*m;
        for(int i=0;i<set.length;i++)
        {
            set[i]=t;
            t++;

        }
        ArrayList<ArrayList<Integer>> all_possible_comb = find_permutations(set,r[0].length);
        int[][] array_APC = new int[all_possible_comb.size()][all_possible_comb.get(0).size()];
        for(int i=0;i<all_possible_comb.size();i++)
        {
            for(int j=0;j<all_possible_comb.get(0).size();j++)
                array_APC[i][j]=all_possible_comb.get(i).get(j);
        }

        for(int[] cut:array_APC)
        {
            //creating tranposed matrix with cut
            for(int i=0;i<r.length;i++)
            {
                for(int j=0;j<r[0].length;j++)
                {
                    matrix[j][i]=r[i][j];
                }
            }
            for(int i=0;i<r[0].length;i++)
            {
                matrix[i][r.length]= cut[i];
            }
            Matrix m1 = new Matrix(matrix);
            //find rref matrix
            LinkedList<LinkedList<Fraction>> rref = m1.RREF();
            Fraction[][] array_rref = new Fraction[rref.size()][rref.get(0).size()];
            for(int i=0;i<rref.size();i++) {
                for (int j = 0; j < rref.get(0).size(); j++) {
                    array_rref[i][j]=rref.get(i).get(j);
                }
            }

            //if rref is consistent
            if(is_consistent(array_rref))
                all_cuts.add(cut);
        }
        total_cuts = all_cuts.size();
        return all_cuts;
    }

    public boolean is_consistent(Fraction[][] array_rref)
    {
        boolean is_consistent=true;
        for(int i=0;i<array_rref.length;i++)
        {
            boolean is_row_zero=true;
            for(int j=0;j<array_rref[0].length-1;j++)
            {
                if(!array_rref[i][j].equals(new Fraction(0)))
                {
                    is_row_zero=false;
                    continue;
                }
            }
            if(is_row_zero && !array_rref[i][array_rref[0].length-1].equals(new Fraction(0)))
            {
                is_consistent=false;
                continue;
            }
        }
        return is_consistent;
    }


    /**
     * initialize parameters to construct and draw a Kirchhoff graph
     *
     * @param r             row matrix
     * @param current_store list of correct cuts according to m
     */
    public void find_kirchhoff_with_cuts(int[][] r, int[][] current_store, int mult, FileWriter writer, File output) {
        this.total_cuts=current_store.length;
        this.edges = this.get_edges_from_matrix(r);
        this.RowSpace = r;
        this.m = mult;
        this.writer = writer;
        this.store = new ArrayList<>(Arrays.asList(current_store));
        int[] zeroth = {0, 0};
        Vertex vZero = new Vertex(zeroth, n);
        ArrayList<Edge> loE = new ArrayList<>();
        ArrayList<Vertex> loV = new ArrayList<>();
        loV.add(vZero);
        Kirchhoff KG = new Kirchhoff(loV, loE,0,0);
        LinkedList<Vertex> todo = new LinkedList<>();
        todo.add(vZero);
        ArrayList<Kirchhoff> validAnswers = new ArrayList<>();
        algo(new ArrayList<>(), todo, KG, validAnswers,output);
        //System.out.println("iterator = "+this.iterator);
        if (validAnswers.size() == 0) {
            System.out.println("No Kirchhoff graph found");
            return;
        }

        int count = 0;
        for (Kirchhoff validAnswer : validAnswers) {
            System.out.print(count + " ");
            print_and_draw(validAnswer, count);
            count++;
        }
    }


    /**
     * find all vertex cuts from row matrix r directly that satisfy multiplicity
     */
    public void find_kirchhoff_with_matrix(int[][] r, int mult, FileWriter writer, File output) {
        this.edges = get_edges_from_matrix(r);
        this.RowSpace = r;
        this.m = mult;
        this.store = find_vertex_cuts(r, mult);
        this.writer = writer;
        int[] zeroth = {0, 0};

        System.out.println("Vertex cuts: " + store.size());
        for(int[] s:store)
        {
            for(int i:s)
                System.out.print(i+" ");
            System.out.println();
        }


        Vertex vZero = new Vertex(zeroth, n);
        ArrayList<Edge> loE = new ArrayList<>();
        ArrayList<Vertex> loV = new ArrayList<>();
        loV.add(vZero);
        Kirchhoff KG = new Kirchhoff(loV, loE,0,0);
        LinkedList<Vertex> todo = new LinkedList<>();
        todo.add(vZero);
        ArrayList<Kirchhoff> validAnswers = new ArrayList<>();
        algo(new ArrayList<>(), todo, KG, validAnswers, output);
        if (validAnswers.size() == 0) {
            System.out.println("No Kirchhoff graph found");
            return;
        }
        int count = 0;
        for (Kirchhoff validAnswer : validAnswers) {
            System.out.print(count + " ");
            print_and_draw(validAnswer, count);
            count++;
        }
    }
}

