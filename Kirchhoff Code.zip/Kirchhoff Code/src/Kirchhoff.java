import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;
import java.util.*;

/**
 * Kirchhoff object
 */
public class Kirchhoff {

    ArrayList<Vertex> loV;
    ArrayList<Edge> loE;
    int depth;
    int enumerate;

    public static void main(String[] args)
    {
        int[]a={0,0};
        int[]b={0,1};
        int[]c={0,2};
        Edge e1=new Edge(a,b,1);
        Edge e2=new Edge(b,c,1);
        ArrayList<Edge> loE = new ArrayList<>();
        loE.add(e1);
        loE.add(e2);
        Vertex v1 = new Vertex(b,c);
        ArrayList<Vertex> loV = new ArrayList<>();
        loV.add(v1);
        Kirchhoff K = new Kirchhoff(loV,loE,0,0);
        System.out.println(K.find_edges_given_vertex(v1));
    }

    public Kirchhoff(ArrayList<Vertex> loV,ArrayList<Edge> loE, int depth, int enumerate)
    {
        this.loV=loV;
        this.loE=loE;
        this.depth=depth;
        this.enumerate=enumerate;
    }

    public Kirchhoff()
    {
        this.loV = new ArrayList<>();
        this.loE = new ArrayList<>();
        this.depth = 0;

    }

    public ArrayList<Edge> find_edges_given_vertex (Vertex v)
    {
        ArrayList<Edge> loE = new ArrayList<>();
        for(Edge e:this.loE)
        {
            if(Arrays.equals(e.head,v.position)||Arrays.equals(e.tail,v.position))
                loE.add(e);
        }
        return loE;
    }

    public boolean is_the_same(Kirchhoff KG)
    {
        return is_same(KG);//||is_opposite(KG);
    }


    public boolean is_same(Kirchhoff KG)
    {
        if(this.loV.size()!=KG.loV.size()||this.loE.size()!=KG.loE.size())
            return false;
        ArrayList<int[]>KG_loC=new ArrayList<>();
        for(int i=0;i<KG.loV.size();i++)
        {
            KG_loC.add(KG.loV.get(i).cut);
        }

        ArrayList<int[]>this_loC=new ArrayList<>();
        for(int i=0;i<this.loV.size();i++)
        {
            this_loC.add(this.loV.get(i).cut);
        }

        for(int[] c:KG_loC)
        {
            boolean boo=false;
            for(int[] c2:this_loC)
            {
                if(Arrays.equals(c,c2))
                {
                    boo=true;
                    break;
                }
            }
            if (!boo)
                return false;
        }
        for(int[] c:this_loC)
        {
            boolean boo=false;
            for(int[] c2:KG_loC)
            {
                if(Arrays.equals(c,c2)) {
                    boo = true;
                    break;
                }
            }
            if (!boo)
                return false;
        }
        return true;
    }

    public boolean is_opposite(Kirchhoff KG)
    {
        if(this.loV.size()!=KG.loV.size()||this.loE.size()!=KG.loE.size())
            return false;
        ArrayList<int[]>KG_loC=new ArrayList<>();
        for(int i=0;i<KG.loV.size();i++)
        {
            int[] neg_cut = new int[KG.loV.get(i).cut.length];
            for(int j=0;j<KG.loV.get(i).cut.length;j++)
                neg_cut[j]=-1*KG.loV.get(i).cut[j];
            KG_loC.add(neg_cut);
        }

        ArrayList<int[]>this_loC=new ArrayList<>();
        for(int i=0;i<this.loV.size();i++)
        {
            this_loC.add(this.loV.get(i).cut);
        }

        //boolean c=false;
        for(int[] c:KG_loC)
        {
            boolean boo=false;
            for(int[] c2:this_loC)
            {
                if(Arrays.equals(c,c2))
                {
                    boo=true;
                    break;
                }
            }
            if (!boo)
                return false;
        }
        for(int[] c:this_loC)
        {
            boolean boo=false;
            for(int[] c2:KG_loC)
            {
                if(Arrays.equals(c,c2)) {
                    boo = true;
                    break;
                }
            }
            if (!boo)
                return false;
        }
        return true;
    }


    public Kirchhoff make_copy (Kirchhoff KG)
    {
        Kirchhoff newKG = new Kirchhoff();
        for (Vertex v:KG.loV)
        {
            newKG.loV.add(v.clone());
        }
        for (Edge e:KG.loE)
        {
            newKG.loE.add(e.clone());
        }
        return newKG;
    }

    @Override
    public boolean equals(Object obj) {
        if(!(obj instanceof Kirchhoff))
            return false;
        Kirchhoff other = (Kirchhoff) obj;
        return this.loV.equals(other.loV) && this.loE.equals(other.loE) && this.is_the_same(other);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.loV, this.loE);
    }
}
