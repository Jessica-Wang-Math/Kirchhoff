import com.google.gson.Gson;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Pattern;
import java.util.*;

public class GraphMaker {
    public static void main(String[] args) throws IOException {

        DrawingThings dt = new DrawingThings();
        //Kirchhoff g = dt.read_and_save("/Users/jessicawang/Desktop/P3d.txt");


        final Pattern VERTEX = Pattern.compile("\\d+,\\d+");
        final Pattern EDGE = Pattern.compile("\\d+,\\d+ \\d+,\\d+ \\d+");
        final Scanner scanner = new Scanner(System.in);
        String input = "";

        ArrayList<Vertex> vertexList = new ArrayList<>();
        ArrayList<Edge> edgeList = new ArrayList<>();

//        ArrayList<Vertex> vertexList =g.loV;
//        ArrayList<Edge> edgeList = g.loE;

        System.out.println("Please input the locations of the vertices in the format 'x,y' (q to quit, d to proceed).");
        while (!input.equalsIgnoreCase("q")) {
            input = scanner.nextLine().trim();
            if (input.equalsIgnoreCase("d")) break;
//            if (!VERTEX.matcher(input).matches()) {
//                System.out.println("Invalid Input! Format: 'x,y'");
//                continue;
//            }

            String[] split = input.split(",");
            int x = Integer.parseInt(split[0]);
            int y = Integer.parseInt(split[1]);

            vertexList.add(new Vertex(new int[]{x, y}, 1));
        }

        System.out.println("Please input the edges of the graph in the format 'x1,y1 x2,y2 weight' (q to quit, d to proceed).");
        while (!input.equalsIgnoreCase("q")) {
            input = scanner.nextLine().trim();
            if (input.equalsIgnoreCase("d")) break;
//            if (!EDGE.matcher(input).matches()) {
//                System.out.println("Invalid Input! Format: 'x1,y1 x2,y2'");
//                continue;
//            }

            String[] vertices = input.split(" ");
            String[] s1 = vertices[0].split(",");
            String[] s2 = vertices[1].split(",");

            int x1 = Integer.parseInt(s1[0]);
            int y1 = Integer.parseInt(s1[1]);
            int x2 = Integer.parseInt(s2[0]);
            int y2 = Integer.parseInt(s2[1]);
            int weight = Integer.parseInt(vertices[2]);

            edgeList.add(new Edge(new int[]{x1, y1}, new int[]{x2, y2}, weight));
        }

        Kirchhoff graph = new Kirchhoff(vertexList, edgeList,0,0);
        //at this point, do whatever you want to do...


        File outputFile = new File("graph_output.txt");

        if (outputFile.exists()) {
            outputFile.delete();
        }
        outputFile.createNewFile();


        try(FileWriter writer = new FileWriter(outputFile,true)) {
            writer.write(0+" ");
            writer.write(new Gson().toJson(graph, Kirchhoff.class) + "\n \n");
        } catch (IOException e) {
            e.printStackTrace();
        }

        GraphDraw draw = new GraphDraw();
        draw.draw_kirchhoff(graph, 0);
    }
}