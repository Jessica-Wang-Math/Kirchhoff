import java.util.Objects;

/**
 * Tuple - helper class used in comparison of edge objects
 * @param <A>
 * @param <B>
 */
public class Tuple<A,B> {
    private final A a;
    private final B b;

    public Tuple(A a, B b) {
        this.a = a;
        this.b = b;
    }

    public A getFirst() {
        return a;
    }

    public B getSecond() {
        return b;
    }

    @Override
    public boolean equals(Object obj) {
        if(!(obj instanceof Tuple))
            return false;
        return a.equals(((Tuple<?, ?>) obj).a) && b.equals(((Tuple<?, ?>) obj).b);
    }

    @Override
    public int hashCode() {
        return Objects.hash(a, b);
    }
}
