
import java.awt.geom.AffineTransform;
import java.awt.geom.Line2D;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.imageio.ImageIO;
import javax.swing.*;

/**
 * Draws a Kirchhoff graph using java graphics
 */
public class GraphDraw extends JFrame {
    int width;
    int height;

    ArrayList<Node> nodes;
    ArrayList<edge> edges;


    public GraphDraw() { //Constructor
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        nodes = new ArrayList<Node>();
        edges = new ArrayList<edge>();
        width = 30;
        height = 30;
    }


    public GraphDraw(String name) { //Construct with label
        this.setTitle(name);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        nodes = new ArrayList<Node>();
        edges = new ArrayList<edge>();
        width = 30;
        height = 30;
    }

    class Node {
        int x, y;
        String name;

        public Node(String myName, int myX, int myY) {
            x = myX;
            y = myY;
            name = myName;
        }
    }

    class edge {
        int i,j,w;

        public edge(int ii, int jj, int weight) {
            i = ii;
            j = jj;
            w = weight;
        }
    }

    //add a node at pixel (x,y)
    public void addNode(String name, int x, int y) {
        nodes.add(new Node(name,x,y));
        this.repaint();
    }

    //add an edge between nodes i and j
    public void addEdge(int i, int j, int weight) {
        edges.add(new edge(i,j, weight));
        this.repaint();
    }

    // actually draw the nodes and edges
    public void paint(Graphics g2) {
        Graphics2D g = (Graphics2D) g2.create();
        FontMetrics f = g.getFontMetrics();
        int nodeHeight = Math.max(height/2, f.getHeight()/5);
        g.setColor(Color.black);
        for (edge e : edges) {

            if(e.w>1)
            {
                //labeling multiplicity
                int x1=nodes.get(e.i).x;
                int x2=nodes.get(e.j).x;
                int y1=nodes.get(e.i).y;
                int y2=nodes.get(e.j).y;
                int a=y2-y1;
                int b=x1-x2;
                int c=a*x1+b*y1;
                int X;
                int Y;

                if(a!=0&&b!=0)
                {
                    X = 5*(x2-x1)/24+x1;
                    Y = (c-a*X)/b;
                }
                else if(b==0)
                {
                    X=x1;
                    Y = 5*(y2-y1)/24+y1;
                }
                else
                {
                    X = 5*(x2-x1)/24+x1;
                    Y=y1;
                }
                g.drawString(String.valueOf(e.w), X, Y);
            }
        }


        g2.setFont(new Font("TimesRoman", Font.PLAIN, 13));
        for (edge e : edges) {
            LineArrow line = new LineArrow(nodes.get(e.i).x, nodes.get(e.i).y,
                    nodes.get(e.j).x, nodes.get(e.j).y,
                    Color.black, 2);
            line.draw(g);
        }

        for (Node n : nodes) {
            int nodeWidth=nodeHeight;
            //int nodeWidth = Math.max(width/3, (f.stringWidth(n.name)+width/6));
            g2.setColor(new Color(20,0,230));
            g2.fillOval(n.x-nodeWidth/2, n.y-nodeHeight/2,
                    nodeWidth, nodeHeight);
            g2.setColor(Color.white);
            g2.drawOval(n.x-nodeWidth/2, n.y-nodeHeight/2,
                    nodeWidth, nodeHeight);
            //g2.drawString(n.name, n.x-nodeWidth/2+f.stringWidth(n.name)/2,
                   // n.y-nodeWidth/2+13);
        }
    }


    public void save(int count)
    {
        BufferedImage bImg = new BufferedImage(this.getWidth(), this.getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D cg = bImg.createGraphics();
        cg.setPaint ( new Color (255,255,255) );
        cg.fillRect ( 0, 0, bImg.getWidth(), bImg.getHeight() );
        this.paintAll(cg);
        try {
            ImageIO.write(bImg, "png", new File("KG"+count+".png"));

        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    class LineArrow {

        int x;
        int y;
        int endX;
        int endY;
        Color color;
        int thickness;

        public LineArrow(int x, int y, int x2, int y2, Color color, int thickness) {
            super();
            this.x = x;
            this.y = y;
            this.endX = x2;
            this.endY = y2;

            this.color = color;
            this.thickness = thickness;
        }

        public void draw(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();

            g2.setColor(color);
            g2.setStroke(new BasicStroke(thickness));
            g2.drawLine(x, y, endX, endY);

            drawArrowHead(g2);
            g2.dispose();
        }

        private void drawArrowHead(Graphics2D g2) {
            double angle = Math.atan2(endY - y, endX - x);
            AffineTransform tx = g2.getTransform();
            tx.translate(endX - ((endX - x) * .12), endY - ((endY - y) * .12));
            tx.rotate(angle - Math.PI / 2d);
            g2.setTransform(tx);
            Polygon arrowHead = new Polygon();
            arrowHead.addPoint(0, 5);
            arrowHead.addPoint(-5, -5);
            arrowHead.addPoint(5, -5);
            g2.fill(arrowHead);
        }

    }



    public void draw_kirchhoff(Kirchhoff graph, int count)
    {
        GraphDraw frame = new GraphDraw("Kirchhoff Graph "+count);

        int x=1000;
        frame.setSize(x,x);
        setLocationRelativeTo(null);

        frame.setVisible(true);
        //frame.pack();
        //bottom left vertex position (x1,y1)
        int x1=graph.loV.get(0).position[0];
        int y1=graph.loV.get(0).position[1];
        //top right vertex position (x2,y2)
        int x2=x1;
        int y2=y1;
        for(Vertex v:graph.loV)
        {
            if(v.position[0]<x1)
                x1=v.position[0];
            if(v.position[1]<y1)
                y1=v.position[1];
            if(v.position[0]>x2)
                x2=v.position[0];
            if(v.position[1]>y2)
                y2=v.position[1];
        }
        int xGap=(x-(x2-x1)*100)/2;
        int yGap=(x-(y2-y1)*100)/2;



        for(int i=0;i<graph.loV.size();i++)
        {
            int[] p =graph.loV.get(i).position;
            //centered using anchor vertex
            frame.addNode(Integer.toString(i),xGap+(p[0]-x1)*100,(x-yGap)-(p[1]-y1)*100);
        }



        for(Edge e:graph.loE)
        {
            int head=-1;
            int tail=-1;
            for(int i=0;i<graph.loV.size();i++)
            {
                if(Arrays.equals(e.head,graph.loV.get(i).position))
                    head=i;
                if(Arrays.equals(e.tail,graph.loV.get(i).position))
                    tail=i;
            }
            frame.addEdge(head,tail, e.weight);
        }
        frame.save(count);
    }
}