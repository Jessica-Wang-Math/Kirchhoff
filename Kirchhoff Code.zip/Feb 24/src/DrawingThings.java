import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.StringReader;
import java.util.Scanner;

public class DrawingThings {


    public static void main(String[] args) throws FileNotFoundException {
        DrawingThings d = new DrawingThings();
        FindKirchhoff f = new FindKirchhoff();
        f.read_and_save("/Users/jessicawang/Desktop/2.txt");
    }
    /**
     * @param path = path of file to be read
     * Read a .txt file with Kirchhoff graphs information
     * Draws them via Java Graphics
     * Saves them as PNGs
     * @throws FileNotFoundException
     * https://www.easepdf.com/png-to-pdf/
     */
    public Kirchhoff read_and_save(String path) throws FileNotFoundException {
        File file = new File(path);
        Scanner s = new Scanner(file);
        FindKirchhoff f = new FindKirchhoff();

//        while (s.hasNextLine())
//        {
            String line = s.nextLine().trim();
            //if (line.isEmpty()) continue;
            String[] parts = line.split(" ");
            int index = (int) Long.parseLong(parts[0]) - 1;
            JsonReader reader = new JsonReader(new StringReader(parts[1]));
            reader.setLenient(true);

            Kirchhoff graph = new Gson().fromJson(reader, Kirchhoff.class);
            f.print_and_draw(graph,0);
            return graph;
        //}

    }


}
