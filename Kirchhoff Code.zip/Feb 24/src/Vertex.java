import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;

/**
 * Vertex object, used in Kirchhoff object
 */
public class Vertex {

    int[] position; //coordinate
    int[] cut; //vertex cut



    public Vertex(int[] position, int[] cut)
    {
        int[] p_copy = new int[position.length];
        System.arraycopy(position, 0, p_copy, 0, position.length);
        int[] c_copy = new int[cut.length];
        System.arraycopy(cut, 0, c_copy, 0, cut.length);
        this.position = p_copy;
        this.cut = c_copy;
    }

    public Vertex(int[]position,int n) //n is number of edges
    {
        this.position=position;
        this.cut = new int[n];
    }

    public void addEdge(int label, boolean isTail)
    {
        if(isTail)
            this.cut[label]++;
        else
            this.cut[label]--;
    }


    public int[] subtract_cuts(int[]c1, int[]c2)
    {
        int[] new_cut = new int[c1.length];
        for(int i=0;i<c1.length;i++)
            new_cut[i]=c1[i]-c2[i];
        return new_cut;
    }

    public boolean cut_is_contained_in_store(int[]c, ArrayList<int[]>store)
    {
        for(int[] i:store)
        {
            boolean is_contained = true;
            for(int j=0;j<c.length;j++)
            {
                if (i[j] != c[j]) {
                    is_contained = false;
                    break;
                }
            }
            if(is_contained==true)
                return true;
        }
        return false;
    }

    public boolean equals_to(Vertex v2)
    {
        if(Arrays.equals(this.position,v2.position) && Arrays.equals(this.cut,v2.cut))
            return true;
        return false;
    }

    public boolean same_position(Vertex v2) {
        return Arrays.equals(this.position, v2.position);
    }

    public boolean same_cut(Vertex v2)
    {
        return Arrays.equals(this.cut, v2.cut);
    }

    public Vertex make_copy(Vertex v2)
    {
        int[] new_position = new int[v2.position.length];
        int[] new_cut = new int[v2.cut.length];
        System.arraycopy(v2.position, 0, new_position, 0, v2.position.length);
        System.arraycopy(v2.cut, 0, new_cut, 0, v2.cut.length);

        Vertex ver = new Vertex(new_position,new_cut);
        return ver;

    }

    public Vertex clone() {
        return new Vertex(position, cut);
    }

    @Override
    public boolean equals(Object other)
    {
        if(!(other instanceof Vertex))
            return false;
        return equals_to((Vertex) other);
    }

    @Override
    public int hashCode() {
        return Objects.hash(Arrays.hashCode(position), Arrays.hashCode(cut));
    }

}
