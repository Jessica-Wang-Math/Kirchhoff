import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class testing {

    public static void main(String[] args)
    {
        FindKirchhoff F = new FindKirchhoff();
        int[] v1_p={0,1};
        int[] v1_c={0,-1,0,0,0};
        Vertex v1 = new Vertex(v1_p,v1_c);
        ArrayList<Vertex> visited= new ArrayList<>();
        visited.add(v1);
        int[] v2p={-1,1};
        int[] v2c={0,0,0,0,1};
        Vertex current = new Vertex(v2p,v2c);
        int[] vCut = {1,0,1,2,1};
        LinkedList<Vertex> todo = new LinkedList<>();
        int[][] r = {{1,0,1,2,1},{0,1,1,1,2}};
        F.edges=F.get_edges_from_matrix(r);
        //F.update_todo(current,vCut,todo,visited,graph);


    }
}
